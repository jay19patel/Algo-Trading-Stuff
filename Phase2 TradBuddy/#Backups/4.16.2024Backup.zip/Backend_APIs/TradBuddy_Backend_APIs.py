
#  ---------------------- BUILT IN MODULES ------------------------
from flask import Flask, request 
from flask_restful import Api, Resource, reqparse  
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity  
from flask_login import LoginManager, UserMixin, login_user, logout_user  
from cryptography.fernet import Fernet  
import json
from datetime import timedelta

#  ---------------------- CUSTOM IN MODULES ------------------------
from Broker.TradBuddy_Broker import TradBuddyBroker


#  ----------------------CREATE INSTANCES------------------------

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'it_is_very_strong_password_123'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=1)

jwt = JWTManager(app)

tb_broker = TradBuddyBroker()




ENCODE_key = b'5KRuqp63vx4HevBI3cNxyH_vW7ug1LnMTKH4ahEWvh4='

def encrypt_data(data):
    cipher_suite = Fernet(ENCODE_key)
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data

# Decrypt data
def decrypt_data(encrypted_data):
    cipher_suite = Fernet(ENCODE_key)
    decrypted_data = cipher_suite.decrypt(encrypted_data)
    return decrypted_data.decode()


api = Api(app)

class Register(Resource):
    def post(self):
        parser = reqparse.RequestParser()

        parser.add_argument('username', type=str, required=True, help='Username is required')
        parser.add_argument('password', type=str, required=True, help='Password is required')
        parser.add_argument('fyers_user_id', type=str, required=True, help='Fyers USER id is required')
        parser.add_argument('fyers_mobile_no', type=str, required=True, help='Fyers MOBILE No is required')
        parser.add_argument('fyers_client_id', type=str, required=True, help='Fyers CLIENT ID is required')
        parser.add_argument('fyers_secret_key', type=str, required=True, help='Fyers SECRET key is required')
        parser.add_argument('fyers_app_pin', type=str, required=True, help='Fyers APP pin is required')
        parser.add_argument('fyers_totp_key', type=str, required=True, help='Fyers TOTP key is required')

        data = parser.parse_args()
        username = data['username']
        password = data['password']
        fyers_user_id = data['fyers_user_id']
        fyers_mobile_no = data['fyers_mobile_no']
        fyers_client_id = encrypt_data(data['fyers_client_id'])
        fyers_secret_key = encrypt_data(data['fyers_secret_key'])
        fyers_app_pin = encrypt_data(data['fyers_app_pin'])
        fyers_totp_key = encrypt_data(data['fyers_totp_key'])

        return tb_broker.profile_create(username=username,
                                        password=password,
                                        fyers_user_id=fyers_user_id,
                                        fyers_mobile_no=fyers_mobile_no,
                                        fyers_client_id=fyers_client_id,
                                        fyers_secret_key=fyers_secret_key,
                                        fyers_app_pin=fyers_app_pin,
                                        fyers_totp_key=fyers_totp_key)
   
class Login(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('profile_id', type=str, required=True, help='Profile ID is required')
        parser.add_argument('password', type=str, required=True, help='Password is required')
        data = parser.parse_args()
        profile_id = data['profile_id']
        password = data['password']

        is_auth = tb_broker.profile_login(profile_id=profile_id,profile_password=password)
        if is_auth.get("status") == "Authenticated":
            is_auth["access_token"] = create_access_token(identity={"profile_id":profile_id,"username":is_auth["body"]})
        return is_auth

class Account(Resource):
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('account_id', type=str, required=True, help='account id is required')

    def _parse_account_id(self):
        data = self.parser.parse_args()
        return data['account_id']

    def post(self):
        return tb_broker.account_create()

    def get(self):
        account_id = self._parse_account_id()
        return tb_broker.account_get(account_id)

    def patch(self):
        account_id = self._parse_account_id()
        tb_broker.account_update(account_id, {})

    def delete(self):
        account_id = self._parse_account_id()
        tb_broker.account_delete(account_id)

class Transection(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('account_id', type=str, required=True, help='account_id is required')
        parser.add_argument('transaction_type', type=str, required=True, help='transaction_type is required')
        parser.add_argument('amount', type=str, required=True, help='amount is required')
        parser.add_argument('notes', type=str, required=True, help='notes is required')
        data = parser.parse_args()
        account_id = data['account_id']
        transaction_type = data['transaction_type']
        amount = data['amount']
        notes = data['notes']

        return tb_broker.account_transaction_create(transaction_type, amount, account_id, notes)

    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('account_id', type=str, required=True, help='account_id is required')
        data = parser.parse_args()
        account_id = data['account_id']
        return tb_broker.account_transaction_view(account_id)



api.add_resource(Register, '/register')
api.add_resource(Login, '/login')





if __name__ == '__main__':
    app.run(debug=True)
