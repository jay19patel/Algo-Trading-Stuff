from Backend_APIs.TradBuddy_Backend_APIs import app
if __name__ == '__main__':
    app.run(debug=True)


