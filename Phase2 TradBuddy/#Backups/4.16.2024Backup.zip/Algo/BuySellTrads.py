import pymongo  


client = pymongo.MongoClient("mongodb+srv://justj:justj@cluster0.fsgzjrl.mongodb.net/")
db =client["TradBuddy_V2_Worker_1"]
account_collection =db["Account"]


data = account_collection.find({})

print(account_collection)

























