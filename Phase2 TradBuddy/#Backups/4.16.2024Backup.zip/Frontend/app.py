from flask import Flask, render_template, request, redirect, url_for, session
from datetime import timedelta

app = Flask(__name__)
app.secret_key = "best_ever_key_is_123"
app.permanent_session_lifetime = timedelta(minutes=60*24)



@app.route('/')
def HomePage():
    if 'username' in session:
        return render_template('Pages/home.html')
    else:
        return redirect(url_for('Login'))


@app.route('/register', methods=['GET', 'POST'])
def Register():
    if request.method == 'POST':
        profile_id = request.form['profile_id']
        profile_password = request.form['profile_password']
        
        if profile_id == '123' and profile_password == "123":
            session.permanent = True
            session['username'] = "Jay Patel" 
            return redirect(url_for('HomePage'))
        else:
            return render_template('Pages/register.html', error='Invalid username or password')
    
    return render_template('Pages/register.html')


@app.route('/login', methods=['GET', 'POST'])
def Login():
    if request.method == 'POST':
        profile_id = request.form['profile_id']
        profile_password = request.form['profile_password']
        
        if profile_id == '123' and profile_password == "123":
            session.permanent = True
            session['username'] = "Jay Patel" 
            return redirect(url_for('HomePage'))
        else:
            return render_template('Pages/login.html', error='Invalid username or password')
    
    return render_template('Pages/login.html')


@app.route('/logout')
def Logout():
    session.pop('username', None)
    return redirect(url_for('Login'))

@app.route('/add_account')
def AddAccount():
     return render_template('Pages/add_account.html')

@app.route('/account_setting')
def AccountSetting():
     return render_template('Pages/accountSetting.html')

@app.route('/account_dashbord')
def AccountDashbord():

    OpenTrades = [
    {'ID': 1, 'Symbol': 'AAPL', 'Buy Price': 150.25, 'SL Price': 155.50, 'Target Price': 500, 'Buy Datetime': '2024-04-15 10:00:00', 'Sell Datetime': '2024-04-15 12:00:00', 'Qnty': 100},
    {'ID': 2, 'Symbol': 'GOOGL', 'Buy Price': 2500.75, 'SL Price': 2520.80, 'Target Price': 2000, 'Buy Datetime': '2024-04-15 11:00:00', 'Sell Datetime': '2024-04-15 13:00:00', 'Qnty': 50}
]
    CloseTrades = [
    {'ID': 3, 'Symbol': 'MSFT', 'Buy Price': 300.50, 'Sell Price': 295.25, 'PnL': -700, 'Buy Datetime': '2024-04-15 09:30:00', 'Sell Datetime': '2024-04-15 11:30:00', 'Qnty': 150},
    {'ID': 4, 'Symbol': 'AMZN', 'Buy Price': 3500.25, 'Sell Price': 3550.80, 'PnL': 3000, 'Buy Datetime': '2024-04-15 10:30:00', 'Sell Datetime': '2024-04-15 12:30:00', 'Qnty': 40}
]

    SummryData = [
            {
                "INDEX": 1,
                "CE_Profit": 100,
                "CE_Amount_Profit": 200,
                "PE_Profit": 150,
                "PE_Amount_Profit": 250,
                "CE_Loss": 50,
                "CE_Amount_Loss": 100,
                "PE_Loss": 75,
                "PE_Amount_Loss": 125,
                "Total_Tred": 200,
                "Total_Tred_Amount": 400
            },
            {
                "INDEX": 2,
                "CE_Profit": 120,
                "CE_Amount_Profit": 220,
                "PE_Profit": 160,
                "PE_Amount_Profit": 270,
                "CE_Loss": 60,
                "CE_Amount_Loss": 110,
                "PE_Loss": 80,
                "PE_Amount_Loss": 130,
                "Total_Tred": 220,
                "Total_Tred_Amount": 420
            }
        ]
    
    return render_template('Pages/accountDashbord.html',OpenTrades=OpenTrades,CloseTrades=CloseTrades,SummryData=SummryData)


@app.route('/update_trad')
def UpdateTrad():

    updatetrad = {"name":1,"age":2}
    return render_template('Pages/UpdateTrad.html',updatetrad=updatetrad)

@app.route('/account_overview')
def accountOverview():
    overviewData = []
    return render_template('Pages/accountOverview.html',overviewData=overviewData)


@app.route('/notification')
def Notification():
    notifications = []
    return render_template('Pages/Notification.html',notifications=notifications)

@app.route('/account_tradbook')
def AccountTradbook():
    tradbook = [
    {
        'Date': '2024-04-15',
        'ID': '1',
        'Symbol': 'AAPL',
        'Buy Price': '$150',
        'Sell Price': '$160',
        'PnL': -250,
        'Buy Datetime': '2024-04-01 09:00:00',
        'Sell Datetime': '2024-04-15 15:00:00',
        'Quantity': '10'
    },
    {
        'Date': '2024-04-14',
        'ID': '2',
        'Symbol': 'GOOGL',
        'Buy Price': '$2500',
        'Sell Price': '$2600',
        'PnL': 500,
        'Buy Datetime': '2024-04-01 10:00:00',
        'Sell Datetime': '2024-04-14 14:00:00',
        'Quantity': '5'
    },
    {
        'Date': '2024-04-13',
        'ID': '3',
        'Symbol': 'MSFT',
        'Buy Price': '$200',
        'Sell Price': '$220',
        'PnL': 200,
        'Buy Datetime': '2024-04-01 11:00:00',
        'Sell Datetime': '2024-04-13 13:00:00',
        'Quantity': '8'
    }
]

    return render_template('Pages/accountTradbook.html',tradbook=tradbook)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080,debug=True)
