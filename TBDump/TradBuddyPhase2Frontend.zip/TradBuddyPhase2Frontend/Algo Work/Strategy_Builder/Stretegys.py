import time


def strategy_1(df, current_price):
    # Placeholder logic for strategy 1
    time.sleep(3)
    return "CE"

def strategy_2(df, current_price):
    # Placeholder logic for strategy 2
    time.sleep(5)
    return "PE"