
# fetch  1 day 1 hourse 30 minuets and etc status and signals like rsi ema and all  for manual entrys