from Strategy_Builder.Strategy_Management import StrategyExecution
import schedule
import time


if __name__ == "__main__":
    StrategyExecution()